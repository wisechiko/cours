module Main where

import System.Environment (getArgs)

import Parser
import Interpreter
 
main :: IO ()
main = do
    args <- getArgs
    str <- readFile $ head args
    let code = parse str []
    let mem = Zipper [0] 0 [0]
    run mem code
    return ()
    
