module Interpreter where

import Prelude hiding (Left, Right)
import Control.Monad (foldM)
import Data.Char (chr, ord)
    
import Parser

 
data Zipper a = Zipper { getLeft :: [a]
                       , getCurr :: a
                       , getRight :: [a]
                       } deriving (Show)

type Mem = Zipper Int

    
-- Basic zipper manipulation             
right :: Num a => Zipper a -> Zipper a
right (Zipper ls c []) = Zipper (c:ls) 0 []
right (Zipper ls c (r:rs)) = Zipper (c:ls) r rs

                             
left :: Num a => Zipper a -> Zipper a
left (Zipper [] c rs) = Zipper [] 0 (c:rs)
left (Zipper (l:ls) c rs) = Zipper ls l (c:rs)
                           

app :: Integral a => (a -> a) -> Zipper a -> Zipper a
app f (Zipper ls c rs) = Zipper ls ((f c) `mod` 256) rs



-- Evaluates the instructions list
eval :: Mem -> BFInstr -> IO Mem
eval mem instr =
    case instr of
      Left  -> return $ left mem
      Right -> return $ right mem
      Incr  -> return $ succ `app` mem
      Decr  -> return $ pred `app` mem
      Read  -> do { c <- getChar; return $ app (\_ -> ord c) mem}
      Write -> putStr [chr $ getCurr mem] >> return mem
      Loop code -> evalLoop mem code
          where evalLoop mem code =
                    case getCurr mem of
                        0 -> return mem
                        _ -> run mem code >>= flip evalLoop code 


-- Runs it all together
run :: Mem -> [BFInstr] -> IO Mem
run = foldM eval 
