module Parser where

import Prelude hiding (Left, Right)

data BFInstr = Left | Right
             | Incr | Decr
             | Read | Write
             | Loop [BFInstr]
               deriving (Show)

parse :: String -> [BFInstr] -> [BFInstr]
parse [] acc = reverse acc
parse ('<':xs) acc = parse xs (Left : acc)
parse ('>':xs) acc = parse xs (Right : acc)
parse ('+':xs) acc = parse xs (Incr : acc)
parse ('-':xs) acc = parse xs (Decr : acc)
parse (',':xs) acc = parse xs (Read : acc)
parse ('.':xs) acc = parse xs (Write : acc)
parse ('[':xs) acc = let (code, rest) = loopCode ('[':xs)
                         in parse rest ((Loop (parse code [])) : acc)
parse (']':xs) acc = reverse acc
parse   (_:xs) acc = parse xs acc


                        
loopCode :: String -> (String, String)
loopCode s = loopCode' s 0 []
    where loopCode' :: String -> Int -> String -> (String, String)
          loopCode' [] 0 acc = (reverse acc, [])
          loopCode' [] _ _ = error "Mismatching Brackets"
          loopCode' (']':xs) 1 acc = (reverse acc, xs)
          loopCode' (']':xs) n acc = loopCode' xs (n-1) (']':acc)
          loopCode' ('[':xs) 0 acc = loopCode' xs 1 acc
          loopCode' ('[':xs) n acc = loopCode' xs (n+1) ('[':acc)
          loopCode' (x:xs) n acc = loopCode' xs n (x:acc)
